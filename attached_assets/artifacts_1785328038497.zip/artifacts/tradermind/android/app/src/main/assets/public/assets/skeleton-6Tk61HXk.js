import{j as s,y as a}from"./index-Ci61aAJp.js";function t({className:e,...r}){return s.jsx("div",{className:a("animate-pulse rounded-md bg-primary/10",e),...r})}export{t as S};
